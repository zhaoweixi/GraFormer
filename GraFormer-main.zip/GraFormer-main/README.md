The code for data preprocessing and model evaluation is borrowed from SemGCN.
[garyzhao/SemGCN](https://github.com/garyzhao/SemGCN)
